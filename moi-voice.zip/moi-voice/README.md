# Moi – Voice First

**Du sprichst. Es entsteht.**

Ruf an. Sag was du brauchst. Leg auf. Fertig.

---

## So funktioniert's

```
Du rufst an: +43 XXX XXX
        ↓
Piep – du sprichst
        ↓
2 Sekunden Stille = fertig (oder sag "fertig")
        ↓
Anruf endet automatisch
        ↓
Ergebnis kommt per SMS/WhatsApp/E-Mail
```

---

## Setup (15 Minuten)

### 1. Twilio Account

1. Geh zu [twilio.com](https://twilio.com)
2. Account erstellen (kostenloser Trial hat $15 Guthaben)
3. Kaufe eine Telefonnummer (z.B. +43 für Österreich)
4. Kopiere: Account SID, Auth Token, Telefonnummer

### 2. Supabase

1. Geh zu [supabase.com](https://supabase.com)
2. Neues Projekt erstellen
3. SQL Editor → Diese Query ausführen:

```sql
-- Users (identifiziert durch Telefonnummer)
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  phone TEXT UNIQUE NOT NULL,
  email TEXT,
  credits INTEGER DEFAULT 3,
  delivery_preference TEXT DEFAULT 'sms',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Alle Interaktionen (für Machine Learning)
CREATE TABLE interactions (
  id SERIAL PRIMARY KEY,
  phone TEXT NOT NULL,
  call_sid TEXT,
  transcript TEXT,
  asset_type TEXT,
  asset_content TEXT,
  file_url TEXT,
  delivery_method TEXT,
  duration INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Feedback (für Selbstlernen)
CREATE TABLE feedback (
  id SERIAL PRIMARY KEY,
  interaction_id TEXT,
  feedback TEXT,
  correction TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Storage Bucket für Dateien
INSERT INTO storage.buckets (id, name, public) 
VALUES ('assets', 'assets', true);
```

4. Settings → API → Kopiere URL + Service Key

### 3. Groq (kostenlos)

1. Geh zu [console.groq.com](https://console.groq.com)
2. API Key erstellen
3. Kopiere den Key

### 4. Anthropic

1. Geh zu [console.anthropic.com](https://console.anthropic.com)
2. API Key erstellen (oder vorhandenen nutzen)

### 5. Vercel deployen

```bash
git clone https://github.com/DEIN-USERNAME/moi-voice.git
cd moi-voice
```

Oder direkt auf Vercel:

1. [vercel.com](https://vercel.com) → Import Git Repository
2. Environment Variables eintragen (siehe .env.example)
3. Deploy

### 6. Twilio Webhook konfigurieren

1. Twilio Console → Phone Numbers → Deine Nummer
2. Voice & Fax → "A Call Comes In"
3. Webhook URL: `https://DEIN-PROJEKT.vercel.app/api/voice`
4. HTTP POST

---

## Kosten

| Service | Kosten |
|---------|--------|
| Vercel | 0€ |
| Supabase | 0€ |
| Groq Whisper | 0€ |
| Twilio Nummer (AT) | ~1€/Monat |
| Twilio eingehend | ~0,01€/Minute |
| Twilio SMS ausgehend | ~0,07€/SMS |
| Claude API | ~0,03€/Asset |

**Pro Anruf (30 Sek + SMS):** ~0,10€

**Break-even:** 20 zahlende User/Monat

---

## Features

### Automatische Asset-Erkennung

| Du sagst... | Moi liefert... |
|-------------|----------------|
| "Präsentation für..." | .pptx Datei |
| "Listing für eBay..." | Fertiger Listing-Text |
| "E-Mail an..." | Fertige E-Mail |
| Alles andere | Passende Antwort |

### Stille-Erkennung

2 Sekunden Stille = Aufnahme beendet.

Kein Button. Kein "fertig" sagen nötig (aber möglich).

### Mehrkanal-Delivery

- SMS (Standard)
- WhatsApp
- E-Mail

User sagt einmal "Schick mir das per WhatsApp" → Moi merkt sich das.

---

## Architektur

```
Anruf eingehend (Twilio)
        ↓
/api/voice (Aufnahme starten)
        ↓
Stille erkannt → Aufnahme beendet
        ↓
/api/voice-status (Recording Callback)
        ↓
Whisper (Transkription)
        ↓
Claude (Asset generieren)
        ↓
PPTX/Text/etc. erstellen
        ↓
Deliver (SMS/WhatsApp/E-Mail)
        ↓
Supabase (Logging für ML)
```

---

## Roadmap

- [x] Eingehende Anrufe
- [x] Spracherkennung
- [x] Asset-Generierung
- [x] SMS-Delivery
- [ ] WhatsApp-Delivery
- [ ] E-Mail-Delivery mit Attachments
- [ ] Ausgehende Anrufe ("Ruf meinen Friseur an")
- [ ] Selbstlernendes Prompt-Tuning
- [ ] Multi-Sprachen (EN, FR, ES, IT)

---

## Lizenz

MIT
