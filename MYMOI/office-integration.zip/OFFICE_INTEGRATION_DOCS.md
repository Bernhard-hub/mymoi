# 📁 Microsoft Office 365 & Google Workspace Integration

## Übersicht

Vollständige Integration von:
- **Microsoft Office 365**: OneDrive, Word, Excel, PowerPoint
- **Google Workspace**: Drive, Docs, Sheets, Slides

## 🔐 OAuth Setup

### Microsoft
1. Azure App registrieren: https://portal.azure.com
2. Redirect URI: `https://mymoi-bot.vercel.app/api/auth/microsoft/callback`
3. API Permissions hinzufügen (siehe erweiterte Scopes)
4. Client ID & Secret in `.env`:
```env
MICROSOFT_CLIENT_ID=your_client_id
MICROSOFT_CLIENT_SECRET=your_client_secret
```

### Google
1. Google Cloud Console: https://console.cloud.google.com
2. OAuth 2.0 Client erstellen
3. Redirect URI: `https://mymoi-bot.vercel.app/api/auth/google/callback`
4. APIs aktivieren: Drive, Docs, Sheets, Slides
5. Credentials in `.env`:
```env
GOOGLE_CLIENT_ID=your_client_id
GOOGLE_CLIENT_SECRET=your_client_secret
```

## 🚀 Erweiterte OAuth Scopes

### Microsoft (vollständig)
```typescript
'https://graph.microsoft.com/Mail.Read',
'https://graph.microsoft.com/Mail.ReadWrite',
'https://graph.microsoft.com/Mail.Send',
'https://graph.microsoft.com/Calendars.Read',
'https://graph.microsoft.com/Calendars.ReadWrite',
'https://graph.microsoft.com/Files.Read',
'https://graph.microsoft.com/Files.ReadWrite',
'https://graph.microsoft.com/Files.Read.All',
'https://graph.microsoft.com/Files.ReadWrite.All',
'https://graph.microsoft.com/Sites.Read.All',
'https://graph.microsoft.com/Sites.ReadWrite.All'
```

### Google (vollständig)
```typescript
'https://www.googleapis.com/auth/gmail.readonly',
'https://www.googleapis.com/auth/gmail.send',
'https://www.googleapis.com/auth/drive',
'https://www.googleapis.com/auth/documents',
'https://www.googleapis.com/auth/spreadsheets',
'https://www.googleapis.com/auth/presentations'
```

## 📚 API Nutzung

### Zentrale Office API
Endpoint: `POST /api/office`

Basis-Struktur:
```typescript
{
  userId: number,
  provider: 'microsoft' | 'google',
  action: string,
  params: object
}
```

---

## 📂 OneDrive / Google Drive

### Dateien auflisten
```typescript
// Microsoft OneDrive
const response = await fetch('/api/office', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    userId: 12345,
    provider: 'microsoft',
    action: 'onedrive:list',
    params: {
      folderId: 'optional_folder_id', // Root wenn leer
      limit: 50
    }
  })
})

// Google Drive
const response = await fetch('/api/office', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    userId: 12345,
    provider: 'google',
    action: 'drive:list',
    params: {
      folderId: 'optional_folder_id',
      limit: 50
    }
  })
})
```

### Datei hochladen
```typescript
// Microsoft OneDrive
{
  userId: 12345,
  provider: 'microsoft',
  action: 'onedrive:upload',
  params: {
    fileName: 'dokument.pdf',
    content: '<base64_content>',
    encoding: 'base64', // oder 'utf-8'
    folderPath: 'Meine Dokumente/Projekte' // optional
  }
}

// Google Drive
{
  userId: 12345,
  provider: 'google',
  action: 'drive:upload',
  params: {
    fileName: 'dokument.pdf',
    content: Buffer.from('...') oder String,
    mimeType: 'application/pdf',
    folderId: 'optional_folder_id'
  }
}
```

### Datei herunterladen
```typescript
// Microsoft
{
  userId: 12345,
  provider: 'microsoft',
  action: 'onedrive:download',
  params: {
    fileId: 'file_id',
    encoding: 'base64' // oder 'utf-8'
  }
}

// Google
{
  userId: 12345,
  provider: 'google',
  action: 'drive:download',
  params: {
    fileId: 'file_id',
    encoding: 'base64'
  }
}
```

### Ordner erstellen
```typescript
// Microsoft
{
  userId: 12345,
  provider: 'microsoft',
  action: 'onedrive:createFolder',
  params: {
    folderName: 'Neuer Ordner',
    parentFolderId: 'optional_parent_id'
  }
}

// Google
{
  userId: 12345,
  provider: 'google',
  action: 'drive:createFolder',
  params: {
    folderName: 'Neuer Ordner',
    parentFolderId: 'optional_parent_id'
  }
}
```

### Datei teilen
```typescript
// Microsoft (Share-Link)
{
  userId: 12345,
  provider: 'microsoft',
  action: 'onedrive:share',
  params: {
    fileId: 'file_id',
    scope: 'anonymous' // oder 'organization'
  }
}

// Google (Freigabe)
{
  userId: 12345,
  provider: 'google',
  action: 'drive:share',
  params: {
    fileId: 'file_id',
    emailAddress: 'user@example.com', // optional bei type='anyone'
    role: 'reader', // 'reader', 'writer', 'commenter'
    type: 'anyone' // 'anyone' oder 'user'
  }
}
```

### Suchen
```typescript
// Microsoft
{
  userId: 12345,
  provider: 'microsoft',
  action: 'onedrive:search',
  params: {
    query: 'Projektplan',
    limit: 20
  }
}

// Google
{
  userId: 12345,
  provider: 'google',
  action: 'drive:search',
  params: {
    query: 'Projektplan',
    limit: 20
  }
}
```

---

## 📝 Word / Google Docs

### Dokument erstellen
```typescript
// Microsoft Word
{
  userId: 12345,
  provider: 'microsoft',
  action: 'word:create',
  params: {
    title: 'Mein Dokument',
    content: 'Text mit\n\nmehreren Absätzen',
    folderPath: 'Dokumente' // optional
  }
}

// Google Docs
{
  userId: 12345,
  provider: 'google',
  action: 'docs:create',
  params: {
    title: 'Mein Dokument',
    content: 'Text mit\n\nmehreren Absätzen',
    folderId: 'optional_folder_id'
  }
}
```

### Dokument lesen
```typescript
// Microsoft Word
{
  userId: 12345,
  provider: 'microsoft',
  action: 'word:read',
  params: {
    fileId: 'document_id'
  }
}

// Google Docs
{
  userId: 12345,
  provider: 'google',
  action: 'docs:read',
  params: {
    documentId: 'document_id'
  }
}
```

---

## 📊 Excel / Google Sheets

### Arbeitsmappe erstellen
```typescript
// Microsoft Excel
{
  userId: 12345,
  provider: 'microsoft',
  action: 'excel:create',
  params: {
    title: 'Meine Tabelle',
    sheets: [
      {
        name: 'Tabelle1',
        data: [
          ['Name', 'Alter', 'Stadt'],
          ['Max', 25, 'Berlin'],
          ['Anna', 30, 'München']
        ]
      },
      {
        name: 'Tabelle2',
        data: [['A', 'B'], [1, 2]]
      }
    ],
    folderPath: 'Tabellen' // optional
  }
}

// Google Sheets
{
  userId: 12345,
  provider: 'google',
  action: 'sheets:create',
  params: {
    title: 'Meine Tabelle',
    sheets: [
      {
        title: 'Tabelle1',
        data: [
          ['Name', 'Alter', 'Stadt'],
          ['Max', 25, 'Berlin']
        ]
      }
    ],
    folderId: 'optional_folder_id'
  }
}
```

### Arbeitsmappe lesen
```typescript
// Microsoft Excel
{
  userId: 12345,
  provider: 'microsoft',
  action: 'excel:read',
  params: {
    fileId: 'workbook_id'
  }
}

// Google Sheets
{
  userId: 12345,
  provider: 'google',
  action: 'sheets:read',
  params: {
    spreadsheetId: 'spreadsheet_id'
  }
}
```

---

## 📊 PowerPoint / Google Slides

### Präsentation erstellen
```typescript
// Microsoft PowerPoint
{
  userId: 12345,
  provider: 'microsoft',
  action: 'powerpoint:create',
  params: {
    title: 'Meine Präsentation',
    slides: [
      {
        slideNumber: 1,
        title: 'Einführung',
        content: 'Willkommen...'
      },
      {
        slideNumber: 2,
        title: 'Hauptteil',
        content: 'Details...'
      }
    ],
    folderPath: 'Präsentationen' // optional
  }
}

// Google Slides
{
  userId: 12345,
  provider: 'google',
  action: 'slides:create',
  params: {
    title: 'Meine Präsentation',
    slides: [
      {
        title: 'Einführung',
        content: ['Punkt 1', 'Punkt 2', 'Punkt 3']
      },
      {
        title: 'Hauptteil',
        content: ['Detail A', 'Detail B']
      }
    ],
    folderId: 'optional_folder_id'
  }
}
```

### Präsentation lesen
```typescript
// Microsoft PowerPoint
{
  userId: 12345,
  provider: 'microsoft',
  action: 'powerpoint:read',
  params: {
    fileId: 'presentation_id'
  }
}

// Google Slides
{
  userId: 12345,
  provider: 'google',
  action: 'slides:read',
  params: {
    presentationId: 'presentation_id'
  }
}
```

---

## 🤖 Integration in MOI Voice Bot

### Beispiel: "Erstelle Word-Dokument in OneDrive"
```typescript
// In action-handlers.ts oder ai-engine.ts
import { createWordDocument } from './lib/microsoft-office'

async function handleVoiceCommand(transcript: string, userId: number) {
  if (transcript.includes('erstelle word') || transcript.includes('word dokument')) {
    // AI generiert Content
    const content = await generateAsset(transcript)
    
    // In OneDrive speichern
    const doc = await createWordDocument(
      userId,
      content.title || 'Neues Dokument',
      content.content,
      'MOI Dokumente'
    )
    
    return {
      message: `✅ Word-Dokument "${doc.title}" erstellt!`,
      link: doc.webUrl
    }
  }
}
```

### Beispiel: "Suche in Google Drive nach Rechnungen"
```typescript
import { searchGoogleDrive } from './lib/google-drive'

async function handleVoiceCommand(transcript: string, userId: number) {
  if (transcript.includes('suche') && transcript.includes('drive')) {
    const query = extractSearchQuery(transcript)
    const results = await searchGoogleDrive(userId, query, 10)
    
    return {
      message: `📂 ${results.length} Dateien gefunden:`,
      files: results.map(f => ({
        name: f.name,
        link: f.webViewLink,
        type: f.type
      }))
    }
  }
}
```

---

## 🔄 Token Management

Beide Implementierungen (`microsoft-office.ts` und `google-drive.ts`) enthalten automatisches Token-Refresh:

- Token wird aus Supabase `user_email_configs` geladen
- Automatische Prüfung der Gültigkeit
- Refresh bei Ablauf
- Aktualisierung in DB

**Kein manuelles Token-Management nötig!**

---

## 📦 Dependencies

```json
{
  "googleapis": "^118.0.0"
}
```

Installation:
```bash
npm install googleapis
```

---

## 🎯 Roadmap / Erweiteru ngen

- [ ] Batch-Operationen
- [ ] Webhook-Benachrichtigungen bei Dateiänderungen
- [ ] Automatische Synchronisation
- [ ] OCR für Bilder in Dokumenten
- [ ] Collaboration Features (Comments, Sharing)
- [ ] Templates für häufige Dokumente
- [ ] PDF-Export aus Word/Docs
- [ ] Chart-Generierung in Sheets
- [ ] Multimedia in Slides

---

## ❓ Support

Bei Fragen oder Problemen:
1. Token-Berechtigungen prüfen
2. Logs in Console checken
3. API-Responses analysieren
4. Microsoft Graph Explorer / Google API Explorer nutzen

**Viel Erfolg! 🚀**
