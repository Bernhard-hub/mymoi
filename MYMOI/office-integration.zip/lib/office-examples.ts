// ============================================
// OFFICE INTEGRATION - MOI Bot Beispiele
// ============================================
// Praktische Verwendung der Microsoft & Google Office Features

import { 
  createWordDocument, 
  createExcelWorkbook, 
  uploadToOneDrive,
  searchOneDrive 
} from './microsoft-office'

import { 
  createGoogleDoc, 
  createGoogleSheet,
  uploadToGoogleDrive,
  searchGoogleDrive 
} from './google-drive'

import { generateAsset } from './ai-engine'

// ============================================
// USE CASE 1: AI-generiertes Dokument in OneDrive speichern
// ============================================

export async function createAIDocumentInOneDrive(
  userId: number,
  prompt: string
): Promise<{ success: boolean; document?: any; error?: string }> {
  try {
    // 1. AI Content generieren
    const asset = await generateAsset(prompt)
    
    // 2. Word-Dokument erstellen
    const doc = await createWordDocument(
      userId,
      asset.title || 'AI Dokument',
      asset.content,
      'MOI/Dokumente' // In speziellen Ordner
    )
    
    return {
      success: true,
      document: {
        id: doc.id,
        name: doc.name,
        url: doc.webUrl,
        message: `✅ Dokument "${doc.name}" in OneDrive erstellt!`
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 2: Excel-Report aus Daten erstellen
// ============================================

export async function createExcelReport(
  userId: number,
  title: string,
  data: Array<{ [key: string]: any }>
): Promise<{ success: boolean; workbook?: any; error?: string }> {
  try {
    // Daten in Sheet-Format konvertieren
    const headers = Object.keys(data[0])
    const rows = data.map(item => headers.map(h => item[h]))
    
    const sheets = [
      {
        name: 'Daten',
        data: [headers, ...rows]
      },
      {
        name: 'Statistik',
        data: [
          ['Anzahl Einträge', data.length],
          ['Erstellt am', new Date().toLocaleDateString()],
          ['Generiert von', 'MOI AI Assistant']
        ]
      }
    ]
    
    // Excel erstellen
    const workbook = await createExcelWorkbook(
      userId,
      title,
      sheets,
      'MOI/Reports'
    )
    
    return {
      success: true,
      workbook: {
        id: workbook.id,
        name: workbook.name,
        url: workbook.webUrl,
        message: `📊 Excel-Report "${workbook.name}" erstellt!`
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 3: Voice Command → Google Doc
// ============================================

export async function voiceToGoogleDoc(
  userId: number,
  transcript: string,
  provider: 'microsoft' | 'google' = 'google'
): Promise<{ success: boolean; document?: any; error?: string }> {
  try {
    // AI Asset generieren
    const asset = await generateAsset(transcript)
    
    if (provider === 'google') {
      // Google Doc erstellen
      const doc = await createGoogleDoc(
        userId,
        asset.title || 'Voice Note',
        asset.content,
        undefined // Root folder
      )
      
      return {
        success: true,
        document: {
          id: doc.id,
          title: doc.title,
          url: doc.webViewLink,
          message: `✅ Google Doc "${doc.title}" erstellt!`
        }
      }
    } else {
      // Microsoft Word erstellen
      const doc = await createWordDocument(
        userId,
        asset.title || 'Voice Note',
        asset.content
      )
      
      return {
        success: true,
        document: {
          id: doc.id,
          name: doc.name,
          url: doc.webUrl,
          message: `✅ Word-Dokument "${doc.name}" erstellt!`
        }
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 4: Intelligente Dateisuche
// ============================================

export async function smartFileSearch(
  userId: number,
  query: string,
  provider: 'microsoft' | 'google' = 'microsoft'
): Promise<{ success: boolean; results?: any[]; error?: string }> {
  try {
    let files
    
    if (provider === 'microsoft') {
      files = await searchOneDrive(userId, query, 20)
    } else {
      files = await searchGoogleDrive(userId, query, 20)
    }
    
    // Ergebnisse formatieren
    const results = files.map(f => ({
      name: f.name,
      type: f.type,
      size: f.size,
      modified: f.modifiedTime,
      url: provider === 'microsoft' ? f.webUrl : f.webViewLink,
      provider
    }))
    
    return {
      success: true,
      results: results,
      message: `🔍 ${results.length} Dateien gefunden für "${query}"`
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 5: Präsentation aus AI-Content
// ============================================

export async function createAIPresentationInOneDrive(
  userId: number,
  topic: string
): Promise<{ success: boolean; presentation?: any; error?: string }> {
  try {
    // AI generiert Präsentations-Content
    const asset = await generateAsset(
      `Erstelle eine professionelle Präsentation über: ${topic}. 
      Format: JSON Array mit slides [{title, bullets: []}]`
    )
    
    // Slides parsen
    const slides = JSON.parse(asset.content)
    
    // PowerPoint in OneDrive erstellen
    // Hinweis: Für vollständige PPT-Generierung würden wir die lokale
    // createPresentation() Funktion nutzen und dann hochladen
    
    const { createPresentation } = await import('./pptx')
    const pptxBuffer = await createPresentation(slides, asset.title || topic)
    
    // In OneDrive hochladen
    const file = await uploadToOneDrive(
      userId,
      `${asset.title || topic}.pptx`,
      pptxBuffer,
      'MOI/Präsentationen'
    )
    
    return {
      success: true,
      presentation: {
        id: file.id,
        name: file.name,
        url: file.webUrl,
        message: `🎨 Präsentation "${file.name}" in OneDrive erstellt!`
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 6: Batch-Upload mehrerer Dateien
// ============================================

export async function batchUploadToCloud(
  userId: number,
  files: Array<{ name: string; content: Buffer | string; mimeType?: string }>,
  provider: 'microsoft' | 'google' = 'microsoft',
  folderPath?: string
): Promise<{ success: boolean; uploaded?: any[]; errors?: any[] }> {
  const results = []
  const errors = []
  
  for (const file of files) {
    try {
      let uploadedFile
      
      if (provider === 'microsoft') {
        uploadedFile = await uploadToOneDrive(
          userId,
          file.name,
          file.content,
          folderPath
        )
      } else {
        uploadedFile = await uploadToGoogleDrive(
          userId,
          file.name,
          file.content,
          file.mimeType || 'application/octet-stream',
          folderPath
        )
      }
      
      results.push({
        name: file.name,
        id: uploadedFile.id,
        success: true
      })
    } catch (error: any) {
      errors.push({
        name: file.name,
        error: error.message
      })
    }
  }
  
  return {
    success: errors.length === 0,
    uploaded: results,
    errors: errors.length > 0 ? errors : undefined,
    message: `📤 ${results.length}/${files.length} Dateien hochgeladen`
  }
}

// ============================================
// USE CASE 7: E-Mail-Anhang in Cloud speichern
// ============================================

export async function saveEmailAttachmentToCloud(
  userId: number,
  emailId: string,
  attachmentData: Buffer,
  attachmentName: string,
  provider: 'microsoft' | 'google' = 'microsoft'
): Promise<{ success: boolean; file?: any; error?: string }> {
  try {
    const folderPath = provider === 'microsoft' 
      ? 'MOI/E-Mail Anhänge' 
      : undefined
    
    let file
    
    if (provider === 'microsoft') {
      file = await uploadToOneDrive(
        userId,
        attachmentName,
        attachmentData,
        folderPath
      )
    } else {
      // Für Google Drive: Ordner-ID statt Path verwenden
      file = await uploadToGoogleDrive(
        userId,
        attachmentName,
        attachmentData,
        'application/octet-stream',
        undefined // folderId könnte hier gesetzt werden
      )
    }
    
    return {
      success: true,
      file: {
        id: file.id,
        name: file.name,
        url: provider === 'microsoft' ? file.webUrl : file.webViewLink,
        message: `💾 Anhang "${file.name}" gespeichert!`
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// USE CASE 8: Wöchentlicher Report automatisieren
// ============================================

export async function createWeeklyReport(
  userId: number,
  activities: Array<{ date: string; activity: string; hours: number }>
): Promise<{ success: boolean; report?: any; error?: string }> {
  try {
    // Excel-Report erstellen
    const reportData = [
      ['Datum', 'Aktivität', 'Stunden'],
      ...activities.map(a => [a.date, a.activity, a.hours]),
      [],
      ['Gesamt', '', activities.reduce((sum, a) => sum + a.hours, 0)]
    ]
    
    const sheets = [{
      name: 'Wochenbericht',
      data: reportData
    }]
    
    const weekNumber = new Date().getWeek() // Wochennummer-Helper
    const title = `Wochenbericht KW${weekNumber} ${new Date().getFullYear()}`
    
    // In OneDrive speichern
    const workbook = await createExcelWorkbook(
      userId,
      title,
      sheets,
      'MOI/Wochenberichte'
    )
    
    return {
      success: true,
      report: {
        id: workbook.id,
        name: workbook.name,
        url: workbook.webUrl,
        message: `📊 Wochenbericht "${workbook.name}" erstellt!`
      }
    }
  } catch (error: any) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============================================
// HELPER: Wochennummer berechnen
// ============================================

declare global {
  interface Date {
    getWeek(): number
  }
}

Date.prototype.getWeek = function() {
  const date = new Date(this.getTime())
  date.setHours(0, 0, 0, 0)
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7)
  const week1 = new Date(date.getFullYear(), 0, 4)
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7)
}

// ============================================
// EXPORT
// ============================================

export const officeExamples = {
  createAIDocumentInOneDrive,
  createExcelReport,
  voiceToGoogleDoc,
  smartFileSearch,
  createAIPresentationInOneDrive,
  batchUploadToCloud,
  saveEmailAttachmentToCloud,
  createWeeklyReport
}
