// ============================================
// CREATIVE STUDIO - MOI INTEGRATION EXAMPLES
// ============================================
// Praktische Beispiele wie User kreativ werden können

import { creativeStudio } from './creative-studio'
import { generateAsset } from './ai-engine'
import { sendSMS, sendWhatsApp } from './twilio-deliver'
import { supabase } from './supabase'

// ============================================
// BEISPIEL 1: "Erstelle mir ein Video über..."
// ============================================

export async function handleVideoCreation(
  transcript: string,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; videoUrl?: string }> {
  try {
    // SMS: Wird bearbeitet
    await sendSMS(phone, '🎬 Video wird erstellt... Dauert ~3 Minuten!')

    // AI generiert optimalen Video-Prompt
    const asset = await generateAsset(
      `Erstelle einen detaillierten Video-Prompt für: ${transcript}`
    )

    // Video generieren
    const video = await creativeStudio.generateVideo(
      asset.content,
      5,
      'cinematic'
    )

    if (video.success && video.videoUrl) {
      // In Supabase speichern
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'video',
        prompt: transcript,
        result_url: video.videoUrl,
        created_at: new Date().toISOString()
      })

      // SMS mit Link
      await sendSMS(
        phone,
        `🎬 Dein Video ist fertig!\n\n${video.videoUrl}\n\n✨ MOI Creative Studio`
      )

      return {
        success: true,
        message: 'Video erfolgreich erstellt!',
        videoUrl: video.videoUrl
      }
    }

    return { success: false, message: 'Video-Generierung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 2: "Komponiere mir einen Song..."
// ============================================

export async function handleMusicCreation(
  description: string,
  userId: number,
  phone: string,
  style?: string,
  instrumental: boolean = false
): Promise<{ success: boolean; message: string; audioUrl?: string }> {
  try {
    await sendSMS(phone, '🎵 Song wird komponiert... ~2 Minuten!')

    const music = await creativeStudio.generateMusic(
      description,
      style || 'pop',
      30,
      instrumental
    )

    if (music.success && music.audioUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'music',
        prompt: description,
        result_url: music.audioUrl,
        metadata: { style, instrumental },
        created_at: new Date().toISOString()
      })

      await sendSMS(
        phone,
        `🎵 Dein Song ist fertig!\n\n${music.audioUrl}\n\n✨ Viel Spaß!`
      )

      return {
        success: true,
        message: 'Song erstellt!',
        audioUrl: music.audioUrl
      }
    }

    return { success: false, message: 'Musik-Generierung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 3: "Klone meine Stimme"
// ============================================

export async function handleVoiceCloning(
  audioSampleUrl: string,
  voiceName: string,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; voiceId?: string }> {
  try {
    await sendSMS(phone, '🎤 Klone deine Stimme... Moment!')

    const result = await creativeStudio.cloneVoice(audioSampleUrl, voiceName)

    if (result.success && result.voiceId) {
      // Voice-ID in DB speichern
      await supabase.from('user_voices').insert({
        user_id: userId,
        voice_id: result.voiceId,
        voice_name: voiceName,
        sample_url: audioSampleUrl,
        created_at: new Date().toISOString()
      })

      await sendSMS(
        phone,
        `🎤 Stimme geklont!\n\nVoice-ID: ${result.voiceId}\n\nNutze sie mit: "Sprich mit meiner Stimme: [Text]"`
      )

      return {
        success: true,
        message: 'Stimme erfolgreich geklont!',
        voiceId: result.voiceId
      }
    }

    return { success: false, message: 'Voice Cloning fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 4: Logo-Generator per Voice
// ============================================

export async function handleLogoCreation(
  companyName: string,
  industry: string,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; logoUrl?: string }> {
  try {
    await sendSMS(phone, '🎨 Erstelle dein Logo... ~30 Sekunden!')

    const logo = await creativeStudio.generateLogo(
      companyName,
      industry,
      'modern'
    )

    if (logo.success && logo.logoUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'logo',
        prompt: `${companyName} - ${industry}`,
        result_url: logo.logoUrl,
        metadata: { variations: logo.variations },
        created_at: new Date().toISOString()
      })

      let message = `🎨 Dein Logo ist fertig!\n\n${logo.logoUrl}`

      if (logo.variations && logo.variations.length > 1) {
        message += '\n\n🎨 Variationen:\n'
        logo.variations.forEach((url, i) => {
          message += `${i + 1}. ${url}\n`
        })
      }

      await sendSMS(phone, message)

      return {
        success: true,
        message: 'Logo erstellt!',
        logoUrl: logo.logoUrl
      }
    }

    return { success: false, message: 'Logo-Generierung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 5: 3D-Modell aus Beschreibung
// ============================================

export async function handle3DModelCreation(
  description: string,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; modelUrl?: string }> {
  try {
    await sendSMS(phone, '🧊 3D-Modell wird erstellt... ~5 Minuten!')

    const model = await creativeStudio.generate3DModel(description, 'realistic')

    if (model.success && model.modelUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: '3d_model',
        prompt: description,
        result_url: model.modelUrl,
        metadata: { preview: model.previewUrl },
        created_at: new Date().toISOString()
      })

      let message = `🧊 Dein 3D-Modell ist fertig!\n\n${model.modelUrl}`

      if (model.previewUrl) {
        message += `\n\n👁️ Vorschau:\n${model.previewUrl}`
      }

      message += '\n\n📥 Download als GLB-Datei'

      await sendSMS(phone, message)

      return {
        success: true,
        message: '3D-Modell erstellt!',
        modelUrl: model.modelUrl
      }
    }

    return { success: false, message: '3D-Generierung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 6: Social Media Post Designer
// ============================================

export async function handleSocialPostDesign(
  text: string,
  platform: 'instagram' | 'facebook' | 'linkedin' | 'twitter',
  theme: string,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; imageUrl?: string }> {
  try {
    await sendSMS(phone, `📱 Erstelle ${platform} Post... ~20 Sekunden!`)

    const post = await creativeStudio.designSocialPost(text, platform, theme)

    if (post.success && post.imageUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'social_post',
        prompt: text,
        result_url: post.imageUrl,
        metadata: { platform, theme },
        created_at: new Date().toISOString()
      })

      await sendSMS(
        phone,
        `📱 Dein ${platform} Post ist fertig!\n\n${post.imageUrl}\n\n✨ Ready to share!`
      )

      return {
        success: true,
        message: 'Social Post erstellt!',
        imageUrl: post.imageUrl
      }
    }

    return { success: false, message: 'Post-Design fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 7: Animiertes GIF aus Bildern
// ============================================

export async function handleGIFCreation(
  imageUrls: string[],
  fps: number,
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; gifUrl?: string }> {
  try {
    await sendSMS(phone, '🎬 Erstelle GIF... ~10 Sekunden!')

    const gif = await creativeStudio.generateAnimatedGIF(imageUrls, fps)

    if (gif.success && gif.gifUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'animated_gif',
        prompt: `GIF aus ${imageUrls.length} Bildern`,
        result_url: gif.gifUrl,
        metadata: { fps, frame_count: imageUrls.length },
        created_at: new Date().toISOString()
      })

      await sendSMS(
        phone,
        `🎬 Dein GIF ist fertig!\n\n${gif.gifUrl}\n\n✨ ${imageUrls.length} Frames @ ${fps} FPS`
      )

      return {
        success: true,
        message: 'GIF erstellt!',
        gifUrl: gif.gifUrl
      }
    }

    return { success: false, message: 'GIF-Erstellung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 8: Tattoo Design Generator
// ============================================

export async function handleTattooDesign(
  description: string,
  style: 'traditional' | 'minimalist' | 'watercolor' | 'tribal' | 'realistic',
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; tattooUrl?: string }> {
  try {
    await sendSMS(phone, '🎨 Erstelle Tattoo-Design... ~30 Sekunden!')

    const tattoo = await creativeStudio.generateTattooDesign(description, style)

    if (tattoo.success && tattoo.tattooUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'tattoo_design',
        prompt: description,
        result_url: tattoo.tattooUrl,
        metadata: { style, stencil: tattoo.stencilUrl },
        created_at: new Date().toISOString()
      })

      let message = `🎨 Dein Tattoo-Design ist fertig!\n\n${tattoo.tattooUrl}`

      if (tattoo.stencilUrl) {
        message += `\n\n📋 Stencil:\n${tattoo.stencilUrl}`
      }

      message += '\n\n⚠️ Zeige es deinem Tattoo-Artist!'

      await sendSMS(phone, message)

      return {
        success: true,
        message: 'Tattoo-Design erstellt!',
        tattooUrl: tattoo.tattooUrl
      }
    }

    return { success: false, message: 'Tattoo-Design fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// BEISPIEL 9: Interior Design Visualisierung
// ============================================

export async function handleInteriorDesign(
  room: 'living-room' | 'bedroom' | 'kitchen' | 'bathroom' | 'office',
  style: 'modern' | 'scandinavian' | 'industrial' | 'bohemian' | 'minimalist',
  preferences: string[],
  userId: number,
  phone: string
): Promise<{ success: boolean; message: string; designUrl?: string }> {
  try {
    await sendSMS(phone, `🏠 Erstelle ${room} Design... ~30 Sekunden!`)

    const interior = await creativeStudio.generateInteriorDesign(
      room,
      style,
      preferences
    )

    if (interior.success && interior.designUrl) {
      await supabase.from('user_creations').insert({
        user_id: userId,
        type: 'interior_design',
        prompt: `${style} ${room}`,
        result_url: interior.designUrl,
        metadata: { preferences },
        created_at: new Date().toISOString()
      })

      await sendSMS(
        phone,
        `🏠 Dein ${room} Design ist fertig!\n\n${interior.designUrl}\n\n✨ ${style} Style`
      )

      return {
        success: true,
        message: 'Interior Design erstellt!',
        designUrl: interior.designUrl
      }
    }

    return { success: false, message: 'Design-Generierung fehlgeschlagen' }

  } catch (error: any) {
    return { success: false, message: error.message }
  }
}

// ============================================
// HELPER: User-Kreationen anzeigen
// ============================================

export async function getUserCreations(
  userId: number,
  type?: string,
  limit: number = 10
): Promise<any[]> {
  let query = supabase
    .from('user_creations')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit)

  if (type) {
    query = query.eq('type', type)
  }

  const { data } = await query

  return data || []
}

// ============================================
// HELPER: Kreativ-Statistiken
// ============================================

export async function getCreativeStats(userId: number): Promise<{
  totalCreations: number
  byType: Record<string, number>
  mostUsed: string
}> {
  const { data } = await supabase
    .from('user_creations')
    .select('type')
    .eq('user_id', userId)

  if (!data || data.length === 0) {
    return {
      totalCreations: 0,
      byType: {},
      mostUsed: ''
    }
  }

  const byType: Record<string, number> = {}
  
  data.forEach(item => {
    byType[item.type] = (byType[item.type] || 0) + 1
  })

  const mostUsed = Object.entries(byType).sort((a, b) => b[1] - a[1])[0][0]

  return {
    totalCreations: data.length,
    byType,
    mostUsed
  }
}

// ============================================
// EXPORT
// ============================================

export const creativeExamples = {
  handleVideoCreation,
  handleMusicCreation,
  handleVoiceCloning,
  handleLogoCreation,
  handle3DModelCreation,
  handleSocialPostDesign,
  handleGIFCreation,
  handleTattooDesign,
  handleInteriorDesign,
  getUserCreations,
  getCreativeStats
}
