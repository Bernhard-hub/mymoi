# MOI – Ehrliche Analyse

## Die Frage

**Warum sollte jemand für Moi zahlen, wenn es Claude gibt?**

---

## Was Claude kann (du jetzt)

- Sprachnachrichten empfangen ✅
- Texte generieren ✅
- Präsentationen erstellen ✅
- Listings schreiben ✅
- Alles was Moi kann ✅

**Kosten:** 20€/Monat (Pro) oder API-Kosten

---

## Was Claude NICHT kann

| Funktion | Claude | Moi |
|----------|--------|-----|
| Datei direkt in dein Drive legen | ❌ | ✅ |
| Listing direkt auf eBay posten | ❌ | ✅ |
| E-Mail direkt versenden | ❌ | ✅ |
| Dein Preismuster lernen | ❌ | ✅ |
| Deinen Schreibstil über Monate speichern | ❌ | ✅ |
| Anruf für dich machen | ❌ | ✅ |
| Termin für dich buchen | ❌ | ✅ |

---

## Der ehrliche Unterschied

**Claude:** Erstellt Dinge.

**Moi:** Erstellt UND liefert UND handelt.

---

## Für wen lohnt sich was?

### Claude reicht für:

- Dich (du weißt wie man promptet)
- Power-User
- Entwickler
- Leute die Copy-Paste nicht stört

### Moi lohnt sich für:

- Leute die nicht wissen was ein "Prompt" ist
- Leute die Zero Friction wollen
- Leute die Moi ihre Arbeit machen lassen wollen (nicht nur denken)
- Volumen-User (100 Listings/Monat → Automation lohnt sich)

---

## Die Rechnung

### Szenario: eBay-Verkäufer

**Mit Claude:**
1. Claude öffnen (5 Sek)
2. Prompt tippen/sprechen (30 Sek)
3. Antwort lesen (10 Sek)
4. Text kopieren (5 Sek)
5. eBay öffnen (10 Sek)
6. Neues Listing erstellen (10 Sek)
7. Text einfügen (5 Sek)
8. Fotos hochladen (30 Sek)
9. Preis eingeben (10 Sek)
10. Veröffentlichen (5 Sek)

**Gesamt: ~2 Minuten pro Listing**

**Mit Moi:**
1. Moi öffnen (5 Sek)
2. Sprechen + Fotos zeigen (30 Sek)
3. Fertig

**Gesamt: ~35 Sekunden pro Listing**

---

### Zeitersparnis

| Listings/Monat | Mit Claude | Mit Moi | Ersparnis |
|----------------|------------|---------|-----------|
| 10 | 20 Min | 6 Min | 14 Min |
| 50 | 100 Min | 30 Min | 70 Min |
| 200 | 400 Min | 120 Min | 280 Min (~5h) |

---

### Geld-Rechnung

**Deine Zeit wert:** 50€/Stunde (Annahme)

| Listings/Monat | Zeitersparnis | Wert der Zeit | Moi-Preis | Gewinn |
|----------------|---------------|---------------|-----------|--------|
| 10 | 14 Min | 12€ | 5€ | +7€ |
| 50 | 70 Min | 58€ | 5€ | +53€ |
| 200 | 280 Min | 233€ | 15€ | +218€ |

**Moi lohnt sich ab ~5 Listings/Monat.**

---

## Aber für DICH persönlich?

Ehrlich: **Grenzwertig.**

Du bist Power-User. Du kennst Claude. Du kannst prompten.

Der Mehrwert für dich:
- Vielleicht 10 Minuten/Tag gespart
- Vielleicht 5 Stunden/Monat

**Wert: ~250€/Monat an Zeit**

**Kosten Moi:** 0€ (du bist der Betreiber)

**Aber:** Du könntest die gleiche Zeit sparen indem du besser promptest.

---

## Wo Moi wirklich glänzt

### Für dich: Als Business

| Metric | Wert |
|--------|------|
| 1.000 User × 5€/Monat | 5.000€/Monat |
| Deine Kosten | ~500€/Monat |
| **Dein Gewinn** | **4.500€/Monat** |

### Für andere: Die keine Ahnung haben

> "Ich will keine App lernen. Ich will einfach reden und dass es passiert."

Das ist 90% der Menschheit.

---

## Die Ein-Tap Lösung

### User Experience

```
1. Öffne moi.app (Bookmark auf Homescreen)
2. Tippe den Kreis
3. Sprich frei
4. 2 Sekunden Stille = automatisch fertig
5. Ergebnis erscheint + wird geliefert
```

### Was der User sieht

```
┌─────────────────────────────────┐
│                                 │
│                                 │
│           ┌───────┐             │
│           │       │             │
│           │  🎤   │             │
│           │       │             │
│           └───────┘             │
│                                 │
│        Tippe und sprich         │
│                                 │
└─────────────────────────────────┘
```

### Während Aufnahme

```
┌─────────────────────────────────┐
│                                 │
│    ● ● ● ● ● ● ● ● ● ● ●       │
│    Höre zu...                   │
│                                 │
│           ┌───────┐             │
│           │       │             │
│           │  ⬛   │             │
│           │       │             │
│           └───────┘             │
│                                 │
│      2 Sek Stille = fertig      │
│                                 │
└─────────────────────────────────┘
```

### Nach Verarbeitung

```
┌─────────────────────────────────┐
│                                 │
│  ✅ Präsentation erstellt       │
│                                 │
│  ┌─────────────────────────┐   │
│  │ 📎 Workshop_OneNote.pptx │   │
│  │                          │   │
│  │  [Öffnen]  [Teilen]     │   │
│  └─────────────────────────┘   │
│                                 │
│  Auch gesendet an:              │
│  📧 bernhard@kph.at             │
│                                 │
│           ┌───────┐             │
│           │  🎤   │             │
│           └───────┘             │
│         Nächste Aufgabe         │
│                                 │
└─────────────────────────────────┘
```

---

## Bezahlung

### Variante A: Einfach

Erste 3 gratis. Dann 5€/Monat unlimited.

**Zahlung:** Stripe. Einmal Kreditkarte hinterlegen. Fertig.

### Variante B: Pay-per-Use

| Asset | Preis |
|-------|-------|
| Text/Listing | 0,20€ |
| Präsentation | 0,50€ |
| E-Mail versenden | 0,10€ |
| Anruf machen | 1,00€ |

**Zahlung:** Prepaid-Guthaben aufladen.

### Variante C: Hybrid (Empfehlung)

- 3 Assets gratis (Trial)
- 5€/Monat für 50 Assets
- 15€/Monat unlimited
- Anrufe/Aktionen extra

---

## Meine Rechnung: Lohnt sich Moi?

### Für dich als User: Nein

Du hast Claude. Du kannst es. Der Mehrwert ist marginal.

### Für dich als Business: Ja

| Jahr 1 | |
|--------|------|
| Ziel | 10.000 User |
| Durchschnitt | 5€/User/Monat |
| Einnahmen | 50.000€/Monat |
| Kosten | ~5.000€/Monat |
| **Gewinn** | **~45.000€/Monat** |

### Für die Welt: Ja

Millionen Menschen die nie lernen werden wie man Claude benutzt.

Aber **anrufen** oder **einen Button drücken** kann jeder.

---

## Fazit

**Moi ist nicht besser als Claude.**

**Moi ist Claude für alle anderen.**

Du baust es. Sie zahlen. Du verdienst.

Dein persönlicher Mehrwert: Das Business.

---

## Nächster Schritt

Soll ich die Ein-Tap Web-App bauen?

Funktioniert auf jedem Handy. Keine Anrufkosten. Weltweit.

Oder: Wir lassen es und du nutzt weiter mich direkt.

Beides ist okay.
