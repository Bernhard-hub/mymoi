# MOI + GENESIS ENGINE

## Komplettpaket

---

## Was ist das?

**Genesis Engine** – Eine KI-Infrastruktur die sich selbst erschafft, verbessert und optimiert.

**Moi** – Das erste Kind. Ein persönlicher Agent: Du sprichst, es entsteht.

---

## Inhalt

```
moi-genesis-package/
│
├── docs/                          ← Dokumentation
│   ├── GENESIS_ENGINE_MANIFEST.md     Vision & Strategie (Markdown)
│   ├── GENESIS_ENGINE_MANIFEST.docx   Vision & Strategie (Word)
│   ├── CHATVERLAUF.md                 Entstehungsgeschichte
│   └── ZUSAMMENFASSUNG.md             Übersicht
│
├── business/                      ← Business Pläne
│   ├── ACQUISITION_PLAN.md            50.000 User in 12 Monaten
│   └── MOI_ANALYSE.md                 Ehrliche Analyse: Lohnt es sich?
│
├── code/                          ← Source Code
│   └── moi-voice/                     Voice-First Web-App
│       ├── app/                       Next.js Frontend
│       ├── lib/                       Core Libraries
│       ├── package.json               Dependencies
│       └── .env.example               Benötigte API Keys
│
└── assets/                        ← Grafiken
    ├── moi-icon-main.png              Profilbild (Gradient)
    ├── moi-icon-neon.png              Profilbild (Neon)
    ├── moi-icon-waveform.png          Profilbild (Waveform)
    └── *.svg                          Vektorgrafiken
```

---

## Quick Start

### 1. Code deployen

```bash
cd code/moi-voice
npm install
```

### 2. API Keys besorgen

- **Twilio** (twilio.com) – Telefonnummer
- **Supabase** (supabase.com) – Datenbank
- **Groq** (console.groq.com) – Whisper (kostenlos)
- **Anthropic** (console.anthropic.com) – Claude

### 3. Vercel deployen

```bash
vercel deploy
```

### 4. Webhook konfigurieren

Twilio Console → Phone Numbers → Voice Webhook:
```
https://dein-projekt.vercel.app/api/voice
```

---

## Die Vision (Kurzfassung)

> **Jahr 1:** Moi – 50.000 User – 4M€ ARR
> 
> **Jahr 2:** Vertikale Mois (Legal, Med, Sales) – 24M€ ARR
> 
> **Jahr 3:** Enterprise – 35M€ ARR
> 
> **Jahr 5:** Platform – 100M€+ ARR

---

## Der Kern-Gedanke

```
Jede Interaktion macht das System intelligenter.
Jeder User macht das System wertvoller.
Jede Sekunde macht das System günstiger.

Automatisch. Ohne menschliches Zutun. Für immer.
```

---

## Kontakt

**Bernhard Strobl**
Genesis Engine / Moi

---

*"Wir bauen es einmal. Dann wächst es. Alleine."*
