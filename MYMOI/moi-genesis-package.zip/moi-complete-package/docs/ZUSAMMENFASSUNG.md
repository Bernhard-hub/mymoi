# MOI VOICE – Zusammenfassung

## Was ist neu?

**Kein Telegram. Kein Button. Nur Anrufen.**

```
Du rufst an → Du sprichst → Du legst auf → Ergebnis kommt
```

---

## Der Flow

1. **Du rufst die Moi-Nummer an**
2. **Piep – du sprichst frei**
   - "Präsentation für meinen Workshop morgen, 90 Minuten, Thema OneNote..."
3. **2 Sekunden Stille = fertig** (oder sag "fertig")
4. **Anruf endet automatisch**
5. **SMS kommt** mit Ergebnis oder Download-Link

---

## Warum besser als Telegram?

| Telegram | Anruf |
|----------|-------|
| Button drücken | Nichts drücken |
| Halten | Einfach reden |
| Loslassen | Stille = fertig |
| Senden drücken | Automatisch |

**Anruf = Natürlichste Interaktion die existiert.**

---

## Was du brauchst

| Service | Was | Kosten |
|---------|-----|--------|
| Twilio | Telefonnummer + Voice | ~1€/Monat + ~0,01€/Min |
| Supabase | Datenbank | 0€ |
| Groq | Whisper Transkription | 0€ |
| Anthropic | Claude API | ~0,03€/Asset |
| Vercel | Hosting | 0€ |

---

## Kosten pro Anruf

- 30 Sek Anruf: 0,005€
- Transkription: 0€
- Claude: 0,03€
- SMS zurück: 0,07€

**Gesamt: ~0,10€ pro Asset**

---

## Nächste Schritte

1. **Twilio Account erstellen** → twilio.com
2. **Telefonnummer kaufen** (AT oder DE)
3. **Supabase Projekt erstellen**
4. **Groq API Key holen** (kostenlos)
5. **Vercel deployen**
6. **Twilio Webhook konfigurieren**

---

## Dateien in diesem Paket

```
moi-voice/
├── README.md               ← Setup-Anleitung
├── CHATVERLAUF.md          ← Unsere Idee
├── ACQUISITION_PLAN.md     ← 50.000 User in 12 Monaten
├── .env.example            ← Alle benötigten Keys
├── app/
│   ├── page.tsx            ← Landingpage (zeigt Nummer)
│   └── api/
│       ├── voice/          ← Eingehende Anrufe
│       ├── voice-done/     ← Nach Aufnahme
│       └── voice-status/   ← Verarbeitung + Delivery
└── lib/
    ├── whisper.ts          ← Spracherkennung
    ├── claude.ts           ← Asset-Generierung
    ├── supabase.ts         ← Datenbank
    ├── deliver.ts          ← SMS/WhatsApp/E-Mail
    └── pptx.ts             ← Präsentationen
```

---

## Das Ziel bleibt

**50.000 User in 12 Monaten.**

Nur jetzt mit einer Interaktion die jeder Mensch auf der Welt versteht:

**Anrufen.**
