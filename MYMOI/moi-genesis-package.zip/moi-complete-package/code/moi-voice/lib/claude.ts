import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

export type AssetType = 'text' | 'listing' | 'presentation' | 'email' | 'call'

export interface GenerateResult {
  type: AssetType
  content: string
  title?: string
}

const SYSTEM_PROMPT = `Du bist Moi. Ein persönlicher Assistent der per Telefon Befehle entgegennimmt.

REGELN:
- Liefere FERTIGE Ergebnisse, keine Entwürfe
- Frag NIEMALS nach mehr Informationen
- Mach das Beste aus dem was du bekommst
- Halte Antworten kurz und prägnant (wird per SMS geliefert)

ERKENNE automatisch was der User will:
- "Listing", "verkaufen", "eBay", "inserieren" → eBay-Listing
- "Präsentation", "Workshop", "Vortrag", "Folien" → Präsentation (JSON für PPTX)
- "Mail", "E-Mail", "schreiben an" → E-Mail
- "Ruf an", "anrufen", "Termin machen bei" → Anruf-Auftrag
- Sonst → Passender kurzer Text

OUTPUT FORMAT:
Antworte IMMER mit JSON:
{
  "type": "listing" | "presentation" | "email" | "call" | "text",
  "title": "Kurzer Titel",
  "content": "Der fertige Inhalt"
}

Für Präsentationen: content ist JSON-Array mit Slides:
[{"title": "...", "bullets": ["...", "..."]}, ...]

Für Anrufe: content enthält Anweisungen was gesagt werden soll

WICHTIG: Halte Text-Antworten unter 300 Zeichen (SMS-Limit).
`

export async function generateAsset(userMessage: string): Promise<GenerateResult> {
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 4096,
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: userMessage }]
  })

  const text = response.content[0].type === 'text' 
    ? response.content[0].text 
    : ''

  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    }
  } catch (e) {
    console.error('JSON parse error:', e)
  }

  // Fallback
  return {
    type: 'text',
    content: text.slice(0, 300), // SMS-Limit
    title: 'Antwort'
  }
}
