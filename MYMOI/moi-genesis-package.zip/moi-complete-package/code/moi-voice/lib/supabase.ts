import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

// User anlegen oder holen (Telefonnummer = ID)
export async function getOrCreateUser(phone: string) {
  const { data: existing } = await supabase
    .from('users')
    .select('*')
    .eq('phone', phone)
    .single()

  if (existing) return existing

  const { data: newUser } = await supabase
    .from('users')
    .insert({
      phone,
      credits: 3,
      delivery_preference: 'sms', // Default: SMS zurück
      created_at: new Date().toISOString()
    })
    .select()
    .single()

  return newUser
}

// Wie will der User seine Assets bekommen?
export async function getUserDeliveryPreference(phone: string): Promise<'sms' | 'whatsapp' | 'email'> {
  const { data } = await supabase
    .from('users')
    .select('delivery_preference, email')
    .eq('phone', phone)
    .single()

  return data?.delivery_preference || 'sms'
}

// Delivery-Präferenz setzen
export async function setDeliveryPreference(phone: string, method: string, email?: string) {
  const update: any = { delivery_preference: method }
  if (email) update.email = email

  await supabase
    .from('users')
    .update(update)
    .eq('phone', phone)
}

// Interaktion speichern (für Machine Learning später)
export async function saveInteraction(data: {
  phone: string
  callSid: string
  transcript: string
  assetType: string
  assetContent: string
  fileUrl: string | null
  deliveryMethod: string
  duration: number
}) {
  await supabase
    .from('interactions')
    .insert({
      ...data,
      created_at: new Date().toISOString()
    })
}

// Credits prüfen und abziehen
export async function useCredit(phone: string): Promise<boolean> {
  const { data: user } = await supabase
    .from('users')
    .select('credits')
    .eq('phone', phone)
    .single()

  if (!user || user.credits <= 0) return false

  await supabase
    .from('users')
    .update({ credits: user.credits - 1 })
    .eq('phone', phone)

  return true
}

// Datei hochladen
export async function uploadFile(fileName: string, fileBuffer: Buffer, contentType: string) {
  const { data, error } = await supabase.storage
    .from('assets')
    .upload(fileName, fileBuffer, { contentType })

  if (error) throw error

  const { data: urlData } = supabase.storage
    .from('assets')
    .getPublicUrl(fileName)

  return urlData.publicUrl
}

// Feedback speichern (für Selbstlernen)
export async function saveFeedback(interactionId: string, feedback: 'positive' | 'negative' | 'corrected', correction?: string) {
  await supabase
    .from('feedback')
    .insert({
      interaction_id: interactionId,
      feedback,
      correction,
      created_at: new Date().toISOString()
    })
}
