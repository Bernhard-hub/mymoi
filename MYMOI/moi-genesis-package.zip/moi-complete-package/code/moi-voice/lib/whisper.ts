// Transkribiert Audio mit Groq Whisper (kostenlos)
export async function transcribeAudio(audioUrl: string): Promise<string> {
  // Audio von Twilio herunterladen
  const audioResponse = await fetch(audioUrl, {
    headers: {
      'Authorization': `Basic ${Buffer.from(
        `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
      ).toString('base64')}`
    }
  })
  
  const audioBuffer = await audioResponse.arrayBuffer()

  // An Groq Whisper senden
  const formData = new FormData()
  formData.append('file', new Blob([audioBuffer]), 'audio.mp3')
  formData.append('model', 'whisper-large-v3')
  formData.append('language', 'de') // Deutsch als Standard

  const response = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.GROQ_API_KEY}`
    },
    body: formData
  })

  const result = await response.json()
  
  if (result.error) {
    console.error('Whisper error:', result.error)
    throw new Error('Transcription failed')
  }

  return result.text || ''
}
