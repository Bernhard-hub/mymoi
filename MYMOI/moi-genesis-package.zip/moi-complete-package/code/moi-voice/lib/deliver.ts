import twilio from 'twilio'
import nodemailer from 'nodemailer'
import { GenerateResult } from './claude'

const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID!,
  process.env.TWILIO_AUTH_TOKEN!
)

const emailTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
})

interface DeliverOptions {
  to: string // Telefonnummer
  method: 'sms' | 'whatsapp' | 'email'
  asset: GenerateResult
  fileUrl: string | null
  user: any
}

export async function deliverAsset(options: DeliverOptions) {
  const { to, method, asset, fileUrl, user } = options

  // Nachricht formatieren
  let message = ''
  
  switch (asset.type) {
    case 'listing':
      message = `🏷️ Listing fertig:\n\n${asset.content}`
      break
    case 'presentation':
      message = `📊 Präsentation fertig: ${asset.title}\n\n${fileUrl || 'Link folgt per E-Mail'}`
      break
    case 'email':
      message = `📧 E-Mail:\n\n${asset.content}`
      break
    case 'call':
      message = `📞 Anruf-Auftrag notiert:\n${asset.content}\n\n(Automatische Anrufe kommen bald)`
      break
    default:
      message = asset.content
  }

  // Ausliefern
  switch (method) {
    case 'sms':
      await sendSMS(to, message, fileUrl)
      break
    case 'whatsapp':
      await sendWhatsApp(to, message, fileUrl)
      break
    case 'email':
      if (user.email) {
        await sendEmail(user.email, asset.title || 'Moi Ergebnis', message, fileUrl)
      } else {
        // Fallback auf SMS wenn keine E-Mail
        await sendSMS(to, message + '\n\n(Tipp: Sag "E-Mail ist xxx@yyy.de" für E-Mail-Versand)', fileUrl)
      }
      break
  }
}

async function sendSMS(to: string, message: string, mediaUrl?: string | null) {
  const options: any = {
    from: process.env.TWILIO_PHONE_NUMBER,
    to,
    body: message.slice(0, 1600) // SMS-Limit
  }
  
  // MMS für Dateien (nur USA/Kanada)
  if (mediaUrl && (to.startsWith('+1'))) {
    options.mediaUrl = [mediaUrl]
  }

  await twilioClient.messages.create(options)
}

async function sendWhatsApp(to: string, message: string, mediaUrl?: string | null) {
  const options: any = {
    from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
    to: `whatsapp:${to}`,
    body: message
  }

  if (mediaUrl) {
    options.mediaUrl = [mediaUrl]
  }

  await twilioClient.messages.create(options)
}

async function sendEmail(to: string, subject: string, text: string, attachmentUrl?: string | null) {
  const mailOptions: any = {
    from: process.env.SMTP_FROM || 'moi@example.com',
    to,
    subject: `Moi: ${subject}`,
    text
  }

  if (attachmentUrl) {
    // Download und anhängen
    const response = await fetch(attachmentUrl)
    const buffer = await response.arrayBuffer()
    
    mailOptions.attachments = [{
      filename: subject.replace(/[^a-zA-Z0-9]/g, '_') + '.pptx',
      content: Buffer.from(buffer)
    }]
  }

  await emailTransporter.sendMail(mailOptions)
}

// Bonus: Outbound-Anruf machen (für "Ruf meinen Friseur an")
export async function makeOutboundCall(to: string, script: string, reportBackTo: string) {
  // TwiML für den Anruf generieren
  const twimlUrl = `${process.env.BASE_URL}/api/outbound-call?script=${encodeURIComponent(script)}&report=${encodeURIComponent(reportBackTo)}`
  
  await twilioClient.calls.create({
    from: process.env.TWILIO_PHONE_NUMBER!,
    to,
    url: twimlUrl
  })
}
