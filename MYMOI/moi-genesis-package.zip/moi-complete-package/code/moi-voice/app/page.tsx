export default function Home() {
  const phoneNumber = process.env.NEXT_PUBLIC_MOI_PHONE || '+43 XXX XXX XXX'
  
  return (
    <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-8">
      <div className="max-w-md text-center space-y-12">
        
        <h1 className="text-6xl font-bold">Moi</h1>
        
        <p className="text-2xl text-gray-400">
          Du sprichst. Es entsteht.
        </p>

        <div className="space-y-6">
          <p className="text-gray-500">Ruf an:</p>
          <a 
            href={`tel:${phoneNumber.replace(/\s/g, '')}`}
            className="block text-4xl font-mono tracking-wider hover:text-gray-300 transition"
          >
            {phoneNumber}
          </a>
        </div>

        <div className="space-y-4 text-left bg-zinc-900 p-6 rounded-lg">
          <p className="text-gray-400 text-sm">So funktioniert's:</p>
          <ol className="space-y-2 text-gray-300">
            <li>1. Du rufst an</li>
            <li>2. Du sagst was du brauchst</li>
            <li>3. Du legst auf (oder sagst "fertig")</li>
            <li>4. Ergebnis kommt per SMS</li>
          </ol>
        </div>

        <div className="space-y-4 text-left bg-zinc-900 p-6 rounded-lg">
          <p className="text-gray-400 text-sm">Beispiele:</p>
          <div className="space-y-3 text-gray-300 text-sm">
            <p>🎤 "Präsentation für OneNote Workshop, 90 Minuten, Volksschullehrer"</p>
            <p>🎤 "eBay Listing für schwarze Lederjacke, Salvatore Santoro, Größe 50"</p>
            <p>🎤 "E-Mail an meinen Chef, bin morgen krank"</p>
          </div>
        </div>

        <p className="text-sm text-gray-600">
          Erste 3 Anrufe kostenlos.
        </p>

      </div>
    </main>
  )
}
