import { NextRequest, NextResponse } from 'next/server'
import twilio from 'twilio'

const VoiceResponse = twilio.twiml.VoiceResponse

// Wird aufgerufen nachdem User aufgelegt oder Stille erkannt wurde
export async function POST(request: NextRequest) {
  const response = new VoiceResponse()
  
  // Kurze Bestätigung
  response.say({ language: 'de-DE' }, 'Erledigt.')
  response.hangup()

  return new NextResponse(response.toString(), {
    headers: { 'Content-Type': 'text/xml' }
  })
}
