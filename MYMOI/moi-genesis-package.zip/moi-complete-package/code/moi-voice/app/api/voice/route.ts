import { NextRequest, NextResponse } from 'next/server'
import twilio from 'twilio'

const VoiceResponse = twilio.twiml.VoiceResponse

// Twilio ruft diese URL wenn jemand anruft
export async function POST(request: NextRequest) {
  const formData = await request.formData()
  const from = formData.get('From') as string
  const callSid = formData.get('CallSid') as string

  const response = new VoiceResponse()

  // Kurzer Ton statt langer Begrüßung
  response.play({ digits: '0' }) // Kurzer Piep

  // Aufnahme starten
  // - maxLength: 120 Sekunden max
  // - timeout: 2 Sekunden Stille = Ende
  // - finishOnKey: # drücken beendet auch
  // - transcribe: false (wir machen das selbst mit Whisper)
  // - recordingStatusCallback: wird aufgerufen wenn Aufnahme fertig
  response.record({
    maxLength: 120,
    timeout: 2, // 2 Sek Stille = fertig
    playBeep: false,
    recordingStatusCallback: `${process.env.BASE_URL}/api/voice-status`,
    recordingStatusCallbackEvent: ['completed'],
    action: `${process.env.BASE_URL}/api/voice-done`,
  })

  // Falls nichts aufgenommen wird
  response.say({ language: 'de-DE' }, 'Keine Aufnahme erhalten. Tschüss.')

  return new NextResponse(response.toString(), {
    headers: { 'Content-Type': 'text/xml' }
  })
}
