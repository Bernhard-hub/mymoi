import { NextRequest, NextResponse } from 'next/server'
import { getOrCreateUser, saveInteraction, getUserDeliveryPreference } from '@/lib/supabase'
import { transcribeAudio } from '@/lib/whisper'
import { generateAsset } from '@/lib/claude'
import { createPresentation } from '@/lib/pptx'
import { deliverAsset } from '@/lib/deliver'

// Twilio ruft diese URL wenn Aufnahme fertig ist
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    
    const recordingUrl = formData.get('RecordingUrl') as string
    const from = formData.get('From') as string // Telefonnummer des Anrufers
    const callSid = formData.get('CallSid') as string
    const duration = formData.get('RecordingDuration') as string

    console.log(`Neue Aufnahme von ${from}: ${duration}s`)

    // User anlegen/holen (Telefonnummer = ID)
    const user = await getOrCreateUser(from)

    // 1. Audio herunterladen und transkribieren
    const audioUrl = `${recordingUrl}.mp3`
    const transcript = await transcribeAudio(audioUrl)
    
    console.log(`Transkript: ${transcript}`)

    // Wenn "fertig/erledigt/senden" am Ende, entfernen
    const cleanedTranscript = transcript
      .replace(/\b(fertig|erledigt|senden|stopp|ende|danke)\b[.!?]?$/i, '')
      .trim()

    // 2. Asset generieren
    const asset = await generateAsset(cleanedTranscript)

    // 3. Falls Präsentation: PPTX erstellen
    let fileUrl = null
    if (asset.type === 'presentation') {
      try {
        const slides = JSON.parse(asset.content)
        const pptxBuffer = await createPresentation(slides, asset.title || 'Präsentation')
        // Upload zu Supabase Storage
        const { uploadFile } = await import('@/lib/supabase')
        const fileName = `${Date.now()}_${asset.title?.replace(/[^a-zA-Z0-9]/g, '_')}.pptx`
        fileUrl = await uploadFile(fileName, pptxBuffer, 'application/vnd.openxmlformats-officedocument.presentationml.presentation')
      } catch (e) {
        console.error('PPTX Fehler:', e)
      }
    }

    // 4. Ausliefern (SMS, WhatsApp, oder E-Mail)
    const deliveryMethod = await getUserDeliveryPreference(from)
    await deliverAsset({
      to: from,
      method: deliveryMethod,
      asset,
      fileUrl,
      user
    })

    // 5. Interaktion speichern (für Lernen)
    await saveInteraction({
      phone: from,
      callSid,
      transcript: cleanedTranscript,
      assetType: asset.type,
      assetContent: asset.content,
      fileUrl,
      deliveryMethod,
      duration: parseInt(duration)
    })

    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('Voice processing error:', error)
    return NextResponse.json({ error: 'Processing failed' }, { status: 500 })
  }
}
