import './globals.css'

export const metadata = {
  title: 'Moi – Du sprichst. Es entsteht.',
  description: 'Ruf an. Sag was du brauchst. Fertig.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  )
}
